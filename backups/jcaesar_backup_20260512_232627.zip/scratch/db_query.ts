import { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma';
import { createEmbedding } from '../lib/ai/index';

async function test() {
  const chatbot = await prisma.chatbot.findFirst({
    where: { dataSources: { some: { status: 'COMPLETED' } } },
    include: { dataSources: true }
  });

  if (!chatbot) return;

  const doc = await prisma.document.findFirst({
    where: { dataSourceId: chatbot.dataSources[0].id }
  });

  if (!doc) return;

  const query = "This domain is for use";
  console.log(`Testing query: ${query}`);

  const embedding = await createEmbedding(query);
  const vectorString = `[${embedding.join(",")}]`;

  const dataSourceIds = chatbot.dataSources.map(ds => ds.id);
  const whereConditions = [Prisma.sql`"dataSourceId" IN (${Prisma.join(dataSourceIds)})`];
  const whereClause = Prisma.join(whereConditions, ' OR ');

  try {
    const documents: any[] = await prisma.$queryRaw`
      WITH filtered_docs AS (
        SELECT id, content, title, url, metadata, embedding
        FROM "Document"
        WHERE ${whereClause}
      )
      SELECT 
        d.id, d.content, d.title, d.url, d.metadata,
        1 - (d.embedding <=> ${vectorString}::vector) as vector_score,
        ts_rank_cd(to_tsvector('simple', d.content), plainto_tsquery('simple', ${query})) as fts_score
      FROM filtered_docs d
    `;
    console.log(`Raw documents length: ${documents.length}`);
    if (documents.length > 0) {
       console.log("First document scores:", {
         vector: documents[0].vector_score,
         fts: documents[0].fts_score
       });
    }
  } catch(e) {
    console.error("SQL Error:", e);
  }
}
test();
