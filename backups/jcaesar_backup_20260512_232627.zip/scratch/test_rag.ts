import { performRAGSearch } from '../lib/ai/index';
import { prisma } from '../lib/prisma';

async function test() {
  // Get any active chatbot with a data source
  const chatbot = await prisma.chatbot.findFirst({
    where: {
      dataSources: { some: { status: 'COMPLETED' } }
    },
    include: { dataSources: true }
  });

  if (!chatbot) {
    console.log("No chatbot found with completed data sources.");
    process.exit(0);
  }

  console.log(`Testing with chatbot: ${chatbot.id}`);
  
  // Try a random query that should match something
  const doc = await prisma.document.findFirst({
    where: { dataSourceId: chatbot.dataSources[0].id }
  });

  if (!doc) {
    console.log("No documents found for this data source.");
    process.exit(0);
  }

  console.log(`Document content snippet: ${doc.content.slice(0, 100)}`);

  // Query using some words from the content
  const query = doc.content.split(' ').slice(0, 5).join(' ');
  console.log(`Testing query: ${query}`);

  try {
    const result = await performRAGSearch({
      chatbotId: chatbot.id,
      query: query,
      limit: 5,
      minSimilarity: 0.1 // very low threshold to see if anything matches
    });

    console.log("RAG Search Result Context length:", result.context.length);
    console.log("Sources found:", result.sources.length);
    console.log("Sources:", result.sources);
  } catch (err) {
    console.error("RAG Search Error:", err);
  }
}

test();
