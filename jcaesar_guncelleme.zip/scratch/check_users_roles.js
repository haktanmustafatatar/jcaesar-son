const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  const users = await prisma.user.findMany();
  console.log("USERS IN DB:");
  users.forEach(u => {
    console.log(`ID: ${u.id}, Email: ${u.email}, ClerkId: ${u.clerkId}, Role: ${u.role}`);
  });
  await prisma.$disconnect();
}

run();
