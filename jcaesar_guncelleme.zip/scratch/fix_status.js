const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const result = await prisma.chatbot.updateMany({
    where: { status: 'TRAINING' },
    data: { status: 'ACTIVE' }
  });
  console.log(`Updated ${result.count} chatbots from TRAINING to ACTIVE`);
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
