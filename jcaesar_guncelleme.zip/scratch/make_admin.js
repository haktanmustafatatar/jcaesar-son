const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  try {
    const email = "haktanmustafas@gmail.com";
    const user = await prisma.user.findFirst({
      where: { email }
    });

    if (!user) {
      console.log(`User with email ${email} not found!`);
      return;
    }

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { role: "SUPERADMIN" }
    });

    console.log(`SUCCESSFULLY UPDATED ${email} to role: ${updated.role}`);
  } catch (err) {
    console.error("Error updating user role:", err);
  } finally {
    await prisma.$disconnect();
  }
}

run();
