const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function test() {
  try {
    const chatbot = await prisma.chatbot.create({
      data: {
        name: "Test Bot " + Date.now(),
        slug: "test-bot-" + Date.now(),
        userId: "clz9999990000000000000000", // Just a fake ID to see if it even reaches DB
        primaryColor: "#000000",
        fontFamily: "Inter, sans-serif",
        borderRadius: "24px",
        widgetShadow: "none",
        status: "TRAINING",
      }
    });
    console.log("Success:", chatbot.id);
  } catch (e) {
    console.error("Prisma Error:", e);
  } finally {
    await prisma.$disconnect();
  }
}

test();
