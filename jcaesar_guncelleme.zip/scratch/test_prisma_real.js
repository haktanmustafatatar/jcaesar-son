const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function test() {
  try {
    const user = await prisma.user.findFirst();
    if (!user) {
      console.log("No user found in DB");
      return;
    }
    
    console.log("Found user:", user.email);

    const chatbot = await prisma.chatbot.create({
      data: {
        name: "Debug Bot " + Date.now(),
        slug: "debug-bot-" + Date.now(),
        userId: user.id,
        primaryColor: "#000000",
        fontFamily: "Inter, sans-serif",
        fontSize: "14px",
        borderRadius: "24px",
        widgetShadow: "none",
        status: "TRAINING",
      }
    });
    console.log("SUCCESS! Created chatbot:", chatbot.id);
  } catch (e) {
    console.error("DETAILED PRISMA ERROR:", e);
  } finally {
    await prisma.$disconnect();
  }
}

test();
