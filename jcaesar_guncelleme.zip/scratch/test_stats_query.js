const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function run() {
  try {
    console.log("1. totalUsers count");
    const totalUsers = await prisma.user.count();
    console.log("totalUsers:", totalUsers);

    console.log("2. totalChatbots count");
    const totalChatbots = await prisma.chatbot.count();
    console.log("totalChatbots:", totalChatbots);

    console.log("3. totalTokens aggregate");
    const totalTokens = await prisma.tokenUsage.aggregate({
      _sum: { tokensUsed: true }
    });
    console.log("totalTokens sum:", totalTokens);

    console.log("4. dailyUsage groupBy");
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const dailyUsage = await prisma.tokenUsage.groupBy({
      by: ['createdAt'],
      where: { createdAt: { gte: sevenDaysAgo } },
      _sum: { tokensUsed: true, cost: true }
    });
    console.log("dailyUsage:", dailyUsage);

    console.log("5. topUsers findMany");
    const topUsers = await prisma.user.findMany({
      include: {
        _count: { select: { chatbots: true } },
        tokenUsages: {
          select: { tokensUsed: true, cost: true }
        }
      },
      take: 10
    });
    console.log("topUsers length:", topUsers.length);
    
    console.log("SUCCESS!");
  } catch (err) {
    console.error("FAILED WITH ERROR:", err);
  } finally {
    await prisma.$disconnect();
  }
}

run();
